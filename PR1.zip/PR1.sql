DELETE FROM ToyOrders
WHERE Toy_ID = 2;
