USE ToyStore;

-- 1. Вивести всі іграшки для дітей віком до 3 років
SELECT Name, Price 
FROM Toys 
WHERE AgeCategory = '0+' OR AgeCategory = '3+';

-- 2. Показати замовлення клієнта "Anna Ivanova"
SELECT o.OrderID, o.OrderDate, o.Status
FROM Orders o
JOIN Customers c ON o.CustomerID = c.CustomerID
WHERE c.FirstName = 'Anna' AND c.LastName = 'Ivanova';

-- 3. Знайти іграшки з кількістю на складі менше 50
SELECT Name, StockQuantity 
FROM Toys 
WHERE StockQuantity < 50;

-- 4. Вивести замовлення з їхньою загальною сумою
SELECT o.OrderID, SUM(od.Quantity * od.UnitPrice) AS TotalAmount
FROM Orders o
JOIN OrderDetails od ON o.OrderID = od.OrderID
GROUP BY o.OrderID;