USE ToyStore;

-- Видалення деталей замовлення
DELETE FROM OrderDetails
WHERE OrderID = 1;

-- Видалення замовлення
DELETE FROM Orders
WHERE OrderID = 1;

-- Видалення іграшки
DELETE FROM Toys
WHERE Name = 'Puzzle "Animals"';