USE ToyStore;

-- Таблиця Постачальників
CREATE TABLE Suppliers (
    SupplierID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL UNIQUE,
    ContactInfo NVARCHAR(255) NULL,
    Address NVARCHAR(255) NULL
);

-- Таблиця Іграшок
CREATE TABLE Toys (
    ToyID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    AgeCategory NVARCHAR(20) NOT NULL,
    Price DECIMAL(10, 2) NOT NULL,
    StockQuantity INT NOT NULL,
    SupplierID INT NOT NULL FOREIGN KEY REFERENCES Suppliers(SupplierID)
);

-- Таблиця Клієнтів
CREATE TABLE Customers (
    CustomerID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName NVARCHAR(50) NOT NULL,
    LastName NVARCHAR(50) NOT NULL,
    ContactInfo NVARCHAR(255) NULL,
    Address NVARCHAR(255) NULL
);

-- Таблиця Замовлень
CREATE TABLE Orders (
    OrderID INT IDENTITY(1,1) PRIMARY KEY,
    OrderDate DATETIME NOT NULL DEFAULT GETDATE(),
    Status NVARCHAR(50) NOT NULL,
    CustomerID INT NOT NULL FOREIGN KEY REFERENCES Customers(CustomerID)
);

-- Таблиця Деталей Замовлення
CREATE TABLE OrderDetails (
    OrderDetailID INT IDENTITY(1,1) PRIMARY KEY,
    OrderID INT NOT NULL FOREIGN KEY REFERENCES Orders(OrderID),
    ToyID INT NOT NULL FOREIGN KEY REFERENCES Toys(ToyID),
    Quantity INT NOT NULL CHECK (Quantity > 0),
    UnitPrice DECIMAL(10, 2) NOT NULL
);