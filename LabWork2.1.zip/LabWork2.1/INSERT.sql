USE ToyStore;

-- Додавання постачальників
INSERT INTO Suppliers (Name, ContactInfo, Address)
VALUES 
    ('HappyToys Inc.', 'contact@happytoys.com', '123 Toy Street, Kyiv'),
    ('KidsWorld LLC', 'sales@kidsworld.com', '456 Play Lane, Lviv');

-- Додавання іграшок
INSERT INTO Toys (Name, AgeCategory, Price, StockQuantity, SupplierID)
VALUES
    ('LEGO Classic', '6+', 25.99, 100, 1),
    ('Teddy Bear', '0+', 15.50, 200, 2),
    ('Puzzle "Animals"', '3+', 10.75, 150, 1);

-- Додавання клієнтів
INSERT INTO Customers (FirstName, LastName, ContactInfo, Address)
VALUES
    ('Anna', 'Ivanova', 'anna@example.com', '789 Oak St, Kharkiv'),
    ('Petro', 'Sydorenko', 'petro@example.com', '101 Maple Ave, Odesa');

-- Додавання замовлень
INSERT INTO Orders (OrderDate, Status, CustomerID)
VALUES
    (GETDATE(), 'Completed', 1),
    (GETDATE(), 'Processing', 2);

-- Додавання деталей замовлення
INSERT INTO OrderDetails (OrderID, ToyID, Quantity, UnitPrice)
VALUES
    (1, 1, 2, 25.99),
    (1, 3, 1, 10.75),
    (2, 2, 3, 15.50);