USE ToyStore;

-- Оновлення ціни іграшки
UPDATE Toys
SET Price = 27.50
WHERE Name = 'LEGO Classic';

-- Оновлення статусу замовлення
UPDATE Orders
SET Status = 'Shipped'
WHERE OrderID = 2;

-- Оновлення контактної інформації клієнта
UPDATE Customers
SET ContactInfo = 'new.email@example.com'
WHERE CustomerID = 1;