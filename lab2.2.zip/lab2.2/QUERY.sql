



Завдання 4 
-- 1. Знайти всі іграшки, ціна яких вища за 50 гривень
SELECT * FROM Toys WHERE Price > 50;


-- 2. Знайти всі замовлення зі статусом 'Completed'
SELECT * FROM Orders WHERE Status = 'Completed';

-- 3. Знайти всі іграшки для дітей віком до 3 років (вікова категорія '0+' або '3+')
SELECT * FROM Toys WHERE AgeCategory IN ('0+', '3+');

-- 4. Знайти всі замовлення, зроблені у 2025 році
SELECT * FROM Orders WHERE OrderDate BETWEEN '2025-01-01' AND '2025-12-31';

-- 5. Знайти всі позиції в деталях замовлення, де кількість товару більше 2
SELECT * FROM OrderDetails WHERE Quantity > 2;


Завдання 5
-- 1. Знайти всі іграшки вартістю понад 30 гривень для дітей віком 6+ років
SELECT * FROM Toys 
WHERE Price > 30 AND AgeCategory = '6+';

-- 2. Знайти всі іграшки з кількістю на складі більше 100 та ціною менше 50 гривень
SELECT * FROM Toys
WHERE StockQuantity > 100 AND Price < 50;

-- 3. Знайти всі завершені замовлення, зроблені у 2024 році
SELECT * FROM Orders
WHERE Status = 'Completed' AND OrderDate BETWEEN '2024-01-01' AND '2024-12-31';

-- 4. Знайти позиції замовлень з кількістю від 2 до 5 одиниць товару
SELECT * FROM OrderDetails
WHERE Quantity >= 2 AND Quantity <= 5;

-- 5. Знайти всі іграшки для дітей віком до 3 років (0+ або 3+), які коштують менше 20 гривень
SELECT * FROM Toys
WHERE (AgeCategory = '0+' OR AgeCategory = '3+') AND Price < 20;

Завдання 6
-- 1. Знайти всі іграшки, назва яких починається на "LEGO"
SELECT * FROM Toys 
WHERE Name LIKE 'LEGO%';

-- 2. Знайти всі іграшки, в назві яких є слово "Puzzle"
SELECT * FROM Toys
WHERE Name LIKE '%Puzzle%';


-- 3. Знайти клієнтів, в адресі яких є слово "St" (Street)
SELECT * FROM Customers
WHERE Address LIKE '%St%';

-- 4. Знайти постачальників, в контактній інформації яких є символ "@" (email)
SELECT * FROM Suppliers
WHERE ContactInfo LIKE '%@%';

-- 5. Іграшки, в назві яких є слово "Set"
SELECT * FROM Toys WHERE Name LIKE '%Set%';

Завдання 7
-- 1. Замовлення з даними клієнтів
SELECT o.OrderID, o.OrderDate, c.FirstName, c.LastName, c.ContactInfo
FROM Orders o
JOIN Customers c ON o.CustomerID = c.CustomerID;

-- 2. Іграшки з інформацією про постачальників (виправлено SupplierName → Name)
SELECT t.ToyID, t.Name AS ToyName, t.Price, s.Name AS SupplierName, s.ContactInfo
FROM Toys t
JOIN Suppliers s ON t.SupplierID = s.SupplierID;

-- 3. Деталізація замовлень (іграшки + кількість)
SELECT od.OrderDetailID, o.OrderDate, t.Name AS ToyName, 
       od.Quantity, t.Price, (od.Quantity * t.Price) AS TotalPrice
FROM OrderDetails od
JOIN Orders o ON od.OrderID = o.OrderID
JOIN Toys t ON od.ToyID = t.ToyID;

-- 4. Постачальники та їх асортимент (виправлено SupplierName → Name)
SELECT s.SupplierID, s.Name AS SupplierName, 
       COUNT(t.ToyID) AS ToyCount, 
       MIN(t.Price) AS MinPrice, 
       MAX(t.Price) AS MaxPrice
FROM Suppliers s
JOIN Toys t ON s.SupplierID = t.SupplierID
GROUP BY s.SupplierID, s.Name;


-- 5. Найпопулярніші іграшки (кількість продаж)
SELECT t.ToyID, t.Name, t.AgeCategory,
       SUM(od.Quantity) AS TotalSold,
       COUNT(DISTINCT od.OrderID) AS OrderCount
FROM Toys t
JOIN OrderDetails od ON t.ToyID = od.ToyID
GROUP BY t.ToyID, t.Name, t.AgeCategory
ORDER BY TotalSold DESC;


Завдання 8.
-- 1. Всі постачальники (навіть без іграшок) + їхні іграшки (RIGHT JOIN)
SELECT t.Name AS ToyName, s.Name AS SupplierName
FROM Toys t
RIGHT JOIN Suppliers s ON t.SupplierID = s.SupplierID;

-- 2. Всі замовлення (навіть без деталей) + їхні позиції (LEFT JOIN)
SELECT o.OrderID, od.Quantity, t.Name AS ToyName
FROM Orders o
LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
LEFT JOIN Toys t ON od.ToyID = t.ToyID;

-- 3. Всі клієнти (навіть без замовлень) + їхні замовлення (RIGHT JOIN)
SELECT c.CustomerID, c.FirstName, c.LastName, o.OrderID, o.OrderDate
FROM Orders o
RIGHT JOIN Customers c ON o.CustomerID = c.CustomerID;

-- 4. Всі постачальники + їхні іграшки (навіть якщо немає іграшок) (LEFT JOIN)
SELECT s.Name AS SupplierName, t.Name AS ToyName, t.Price
FROM Suppliers s
LEFT JOIN Toys t ON s.SupplierID = t.SupplierID;

-- 5. Всі іграшки + їхні покупці (через ланцюжок LEFT JOIN)
SELECT t.Name AS ToyName, c.FirstName, c.LastName, od.Quantity
FROM Toys t
LEFT JOIN OrderDetails od ON t.ToyID = od.ToyID
LEFT JOIN Orders o ON od.OrderID = o.OrderID
LEFT JOIN Customers c ON o.CustomerID = c.CustomerID;


Завдання 9.
USE ToyStore;
SELECT
    o.OrderID,
    o.OrderDate,
    c.FirstName,
    c.LastName,
    (
        SELECT SUM(od.Quantity * t.Price)
        FROM OrderDetails od
        JOIN Toys t ON od.ToyID = t.ToyID
        WHERE od.OrderID = o.OrderID
    ) AS OrderTotal
FROM Orders o
JOIN Customers c ON o.CustomerID = c.CustomerID
WHERE EXISTS (
    SELECT 1
    FROM OrderDetails od
    WHERE od.OrderID = o.OrderID
);
-- 2. Постачальники з іграшками вище середньої ціни
SELECT s.SupplierID, s.Name AS SupplierName
FROM Suppliers s
WHERE s.SupplierID IN (
    SELECT t.SupplierID
    FROM Toys t
    WHERE t.Price > (SELECT AVG(Price) FROM Toys)
);

-- 3. Клієнти з кількістю замовлень вище середньої
SELECT c.CustomerID, c.FirstName, c.LastName
FROM Customers c
WHERE c.CustomerID IN (
    SELECT o.CustomerID
    FROM Orders o
    GROUP BY o.CustomerID
    HAVING COUNT(o.OrderID) > (
        SELECT AVG(OrderCount)
        FROM (
            SELECT COUNT(OrderID) AS OrderCount
            FROM Orders
            GROUP BY CustomerID
        ) AS CustomerOrders
    )
);

-- 4. Іграшки постачальників з великим асортиментом (>5 іграшок)
SELECT t.ToyID, t.Name AS ToyName
FROM Toys t
WHERE t.SupplierID IN (
    SELECT s.SupplierID
    FROM Suppliers s
    JOIN Toys t ON s.SupplierID = t.SupplierID
    GROUP BY s.SupplierID
    HAVING COUNT(t.ToyID) > 5
);

SELECT 
    t.ToyID,
    t.Name AS ToyName,
    (
        SELECT SUM(od.Quantity)
        FROM OrderDetails od
        WHERE od.ToyID = t.ToyID
    ) AS TotalQuantity
FROM Toys t
WHERE (
    SELECT SUM(od.Quantity)
    FROM OrderDetails od
    WHERE od.ToyID = t.ToyID
) > 0
ORDER BY TotalQuantity DESC;


Завдання 10
-- 1. Постачальники з кількістю іграшок більше 3
SELECT s.Name AS SupplierName, COUNT(t.ToyID) AS ToyCount
FROM Suppliers s
INNER JOIN Toys t ON s.SupplierID = t.SupplierID
GROUP BY s.Name
HAVING COUNT(t.ToyID) > 3;

-- 2. Клієнти з кількістю замовлень більше 2
SELECT c.FirstName, c.LastName, COUNT(o.OrderID) AS OrderCount
FROM Customers c
INNER JOIN Orders o ON c.CustomerID = o.CustomerID
GROUP BY c.FirstName, c.LastName
HAVING COUNT(o.OrderID) > 2;

-- 3. Іграшки з загальною кількістю продажів більше 10
SELECT t.Name AS ToyName, SUM(od.Quantity) AS TotalSold
FROM Toys t
INNER JOIN OrderDetails od ON t.ToyID = od.ToyID
GROUP BY t.Name
HAVING SUM(od.Quantity) > 10;

-- 4. Замовлення з загальною вартістю більше 300
SELECT o.OrderID, 
       c.FirstName + ' ' + c.LastName AS CustomerName,
       SUM(od.Quantity * t.Price) AS OrderTotal
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
INNER JOIN OrderDetails od ON o.OrderID = od.OrderID
INNER JOIN Toys t ON od.ToyID = t.ToyID
GROUP BY o.OrderID, c.FirstName, c.LastName
HAVING SUM(od.Quantity * t.Price) > 50;

-- 5. Постачальники з середньою ціною іграшок вище 50
SELECT s.Name AS SupplierName, AVG(t.Price) AS AvgPrice
FROM Suppliers s
INNER JOIN Toys t ON s.SupplierID = t.SupplierID
GROUP BY s.Name
HAVING AVG(t.Price) > 50;

Завдання 11
1. Список замовлень з клієнтами та сумами 
sql
SELECT 
    o.OrderID,
    o.OrderDate,
    c.FirstName,
    c.LastName,
    SUM(od.Quantity * t.Price) AS OrderTotal
FROM Orders o
JOIN Customers c ON o.CustomerID = c.CustomerID
JOIN OrderDetails od ON o.OrderID = od.OrderID
JOIN Toys t ON od.ToyID = t.ToyID
GROUP BY o.OrderID, o.OrderDate, c.FirstName, c.LastName;

2. Постачальники та кількість їхніх іграшок (GROUP BY)
sql
SELECT 
    s.Name AS SupplierName,
    COUNT(t.ToyID) AS ToyCount
FROM Suppliers s
LEFT JOIN Toys t ON s.SupplierID = t.SupplierID
GROUP BY s.Name;
3. Найпопулярніші іграшки (сортування за кількістю продажів)
sql
SELECT 
    t.Name AS ToyName,
    SUM(od.Quantity) AS TotalSold
FROM Toys t
JOIN OrderDetails od ON t.ToyID = od.ToyID
GROUP BY t.Name
ORDER BY TotalSold DESC;
4. Клієнти та їхня кількість замовлень (проста статистика)
sql
SELECT 
    c.FirstName,
    c.LastName,
    COUNT(o.OrderID) AS OrderCount
FROM Customers c
LEFT JOIN Orders o ON c.CustomerID = o.CustomerID
GROUP BY c.FirstName, c.LastName;
5. Іграшки з ціною вище середньої (простий підзапит)
sql
SELECT 
    Name,
    Price
FROM Toys
WHERE Price > (SELECT AVG(Price) FROM Toys);
Завдання 11
Клієнтська активність

SELECT 
    c.CustomerID,
    c.FirstName,
    c.LastName,
    COUNT(DISTINCT o.OrderID) AS OrderCount,
    SUM(od.Quantity * t.Price) AS TotalSpent,
    DATEDIFF(DAY, MAX(o.OrderDate), GETDATE()) AS DaysSinceLastOrder
FROM Customers c
LEFT JOIN Orders o ON c.CustomerID = o.CustomerID
LEFT JOIN OrderDetails od ON o.OrderID = od.OrderID
LEFT JOIN Toys t ON od.ToyID = t.ToyID
GROUP BY c.CustomerID, c.FirstName, c.LastName
HAVING COUNT(DISTINCT o.OrderID) > 0
ORDER BY TotalSpent DESC;
SELECT 
    t.ToyID,
    t.Name,
    t.AgeCategory,
    t.Price,
    SUM(od.Quantity) AS TotalSold,
    SUM(od.Quantity * t.Price) AS TotalRevenue,
    COUNT(DISTINCT o.CustomerID) AS UniqueCustomers
FROM Toys t
JOIN OrderDetails od ON t.ToyID = od.ToyID
JOIN Orders o ON od.OrderID = o.OrderID
GROUP BY t.ToyID, t.Name, t.AgeCategory, t.Price
HAVING SUM(od.Quantity) > 0
ORDER BY TotalSold DESC;

Завдання 12
USE ToyStore;
-- 1. Іграшки з високим запасом та конкретним постачальником
SELECT
    t.Name AS ToyName,
    t.Price,
    t.StockQuantity,
    s.Name AS SupplierName
FROM Toys t
INNER JOIN Suppliers s ON t.SupplierID = s.SupplierID
WHERE t.StockQuantity > 50
  AND s.Name LIKE '%Toys%'
  AND t.Price BETWEEN 20 AND 100;


-- 3. Дорогі іграшки з певною віковою каиегорією
SELECT
    t.Name AS ToyName,
    t.Price,
    t.StockQuantity,
    t.AgeCategory,
    s.Name AS SupplierName,
    s.ContactInfo
FROM Toys t
INNER JOIN Suppliers s ON t.SupplierID = s.SupplierID
WHERE t.Price > 50
  AND t.AgeCategory IN ('7+', '8+', '10+');

-- 4. Великі замовлення (з деталізацією)
SELECT
    o.OrderID,
    c.FirstName + ' ' + c.LastName AS CustomerName,
    SUM(od.Quantity * t.Price) AS OrderTotal,
    COUNT(t.ToyID) AS UniqueToysCount
FROM Orders o
INNER JOIN Customers c ON o.CustomerID = c.CustomerID
INNER JOIN OrderDetails od ON o.OrderID = od.OrderID
INNER JOIN Toys t ON od.ToyID = t.ToyID
GROUP BY o.OrderID, c.FirstName, c.LastName
HAVING SUM(od.Quantity * t.Price) > 50
ORDER BY OrderTotal DESC;

-- 5. Актуальні іграшки (з перевіркою вікових категорій)
SELECT
    t.Name AS ToyName,
    t.AgeCategory,
    t.Price,
    s.Name AS SupplierName,
    DATEDIFF(DAY, GETDATE(), DATEADD(MONTH, 6, GETDATE())) AS DaysUntilExpiration
FROM Toys t
INNER JOIN Suppliers s ON t.SupplierID = s.SupplierID
WHERE t.AgeCategory NOT IN ('0+', '3+')
  AND t.StockQuantity > 0
  AND t.Price < (
    SELECT AVG(Price)
    FROM Toys
    WHERE AgeCategory = t.AgeCategory
  )
ORDER BY t.Price DESC;

Завдання 13
Посилання на репозиторій:https://github.com/IvanVoityk/DataBase
